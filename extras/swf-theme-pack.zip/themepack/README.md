# SWF theme pack

Four example themes for Simple Website Framework, each built for a different job.
System fonts throughout — no `@import`, no downloads, no build step.

Open `index.html` and work through the four previews.

| Theme | For | Signature |
|---|---|---|
| **Ledger** | Documentation, handbooks, changelogs | A hairline rail down the content column that headings notch into |
| **Atelier** | Studio and portfolio | An oversized wordmark cropped by the viewport; monochrome by design |
| **Almanac** | Essays and long-form writing | Sidenotes floating into the right margin, no JavaScript |
| **Beacon** | Product and marketing | A shelf of proof points overlapping the header/page seam |

---

## Install one

```
themes/<name>/              → themes/<name>/
pages/<name>/home.html      → pages/home.html
pages/<name>/navigation.html → pages/navigation.html
pages/<name>/footer/*       → pages/footer/
```

```php
$theme = "ledger";   // or atelier, almanac, beacon
```

The demo pages reference images already in the framework's `images/` folder. The
`images/` folder in this pack holds downscaled copies purely so the previews render
offline — you don't need to install it.

Ledger uses `simplewebframe_wordmark.png` in its header and `simplewebframe_logo.png`
in its footer, so it works as a documentation site for the framework itself out of the
box. Swap both for your own artwork, or delete the `<img>` from `header.php` and put
the text title back.

---

## They share a vocabulary

Every theme implements the same core classes, so a page written for one renders
sensibly in any of them. Switch `$theme` and the content survives.

| Class | Does | Modifiers |
|---|---|---|
| `band` | Full-width horizontal band | `band-tight` `band-sunk` `band-inverse` |
| `wrap` | Centred max-width container | `wrap-narrow` `wrap-wide` |
| `stack` | Even vertical gap between children | `stack-lg` |
| `cluster` | Horizontal group that wraps | `cluster-center` `cluster-between` |
| `card` | Bounded content block | — |
| `feature` | Icon, heading, description | — |
| `btn` | Button | varies by theme |
| `eyebrow` | Small caps label above a heading | — |

Reading width comes from `.measure` in `base.css`. `.lead`, `.hug`, `.flush`,
`.table-scroll` and `.visually-hidden` are also baseline, not theme.

Each theme then adds what only it needs — `.railed` and `.callout` in Ledger,
`.sidenote` and `.article` in Almanac, `.index` and `.bleed` in Atelier, `.shelf` and
`.plan` in Beacon.

**None of them define `.section`.** The page templates already emit
`<div class="section group">`, so that class is effectively reserved.

---

## Ledger

Documentation. The reader is scanning for one specific thing and then copying code
out of it.

- **The rail.** One hairline down the left of `.railed`, with a short teal notch at
  every `h2` and a fainter one at every `h3`. You can see the shape of a long page in
  peripheral vision without a table of contents.
- **Filename tabs.** `.codeblock` wraps a `.filename` span and a `pre`; the tab
  joins the top of the block. The single most useful thing you can put on a code
  sample.
- **Three callouts.** `.callout`, `.callout-warn`, `.callout-danger`. Three is
  enough; more and nobody reads any of them.
- `pre.terminal` inverts for shell transcripts. Tables use tabular figures.
- Teal accent rather than blue, so links don't read as unstyled browser defaults.

## Atelier

A studio site. The work is the argument; the type gets out of the way.

- **The wordmark.** This is the hero — the site title set as huge display type, not an
  image file. Tracking is pulled to `-0.055em` and the frame has `overflow: hidden`, so
  the page opens with a piece of type too big to fit. Two lines, one bold and one thin.
- **It sizes itself to the title.** `header.php` counts the characters with `mb_strlen()`
  and passes them in as `--wordmark-chars`; the font size is the available width divided
  by that count. A seven-letter name and a twenty-letter name both fill the viewport.
  Lower the number by hand to set it larger.
- **Monochrome, deliberately.** There is no accent colour anywhere in the file. The
  only colour on the page comes from the work.
- **`.bleed`** breaks any image out to full viewport width from inside any container.
  It's paired with `overflow-x: clip` on the root, because `100vw` is measured to the
  outside of the vertical scrollbar and would otherwise put a horizontal scrollbar on
  every page long enough to scroll. `clip` rather than `hidden` — `hidden` on `html`
  or `body` silently breaks `position: sticky`, which the nav needs.
- **`.index`** is the contents page: year, title, discipline on a hairline row, the
  whole row a link, sliding right slightly on hover.
- No filled buttons — a solid black rectangle would shout louder than the work.

## Almanac

Long-form reading.

- **Sidenotes.** `<span class="sidenote">` immediately after the word it annotates.
  Floats into the right margin beside its paragraph; collapses to an indented aside
  below 1000px. One float and one negative margin, no JavaScript.
- **`.article`** is wide enough to hold both the reading column and the note margin.
  Its children are capped at the reading width; figures and `.wide` opt out and use
  the whole block.
- **Drop cap** on `p.opening` only — the first paragraph after the title, nowhere else.
- Body is 19px old-style serif with old-style figures in running text and lining
  tabular figures in tables.
- **The pairing is inverted on purpose:** humanist sans for headings, old-style serif
  for body. Most editorial themes do the reverse. This way the headings stay
  businesslike and the reading text keeps the warmth.

## Beacon

Product pages that end in a pricing table.

- **The shelf.** The proof-point row sits in a card pulled up by `-5.5rem` into the
  dark header, which carries extra bottom padding to make room. The two halves are
  stitched by one element instead of meeting at a seam, and the first thing below the
  fold is already half visible above it.
- **Dot grid** on the header — texture on flat indigo without reaching for a gradient.
- `.plan` and `.plan-featured` for pricing; `.stat` / `.stat-label` for numbers;
  `.screenshot` for product images; `.badge` for the "popular" pill.
- Pill buttons, violet primary, amber reserved for the badge alone.

---

## Customising any of them

Section 1 of each `custom.css` is the whole control panel. The palette is declared
under its own names, then mapped onto the variables `base.css` reads:

```css
--teal: #0b6b62;

--color-link:  var(--teal);
--color-focus: var(--teal);
```

So `base.css` styles every element in the theme's colours without the theme writing a
single element rule. Same for the type scale — each theme sets `--h1` through `--h4`
rather than declaring `h1 { font-size: … }`.

To swap in a web font, add one `@import` at the top and repoint `--font-body` or
`--font-heading`. Nothing else needs to change.

All four ship a `prefers-color-scheme: dark` block, in every case a self-contained
set of variable reassignments you can delete without touching anything below it.
