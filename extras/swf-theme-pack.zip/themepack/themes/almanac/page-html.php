
	<!-- Primary Page Layout
	–––––––––––––––––––––––––––––––––––––––––––––––––– -->
	<main class="contentcontainer">
		<div class="pagetitle">
		<?php if ($pagename != "home" || $showhomepagetitle == true) { ?>
			<?php if (isset($pagetitle)) { ?>
				<h1><?php echo $pagetitle; ?></h1>
					<?php if ($pagetype == "article") { ?>
					
						<?php echo "<p class=\"pagedate\">" . formatDate($pagedate, 'pretty') . "</p>"; ?>
						<?php echo "<p class=\"pageauthor\">Written by <i>" . $pageauthor . "</i></p>"; ?>
					<?php } ?>
			<?php } else { ?>	
					<h1><?php echo ucwords($pagename); ?></h1>
			<?php } ?>
		<?php } ?>
		</div>
		<div class="content">
			<div class="section group">
					<?php
						$filename = swf_page_source($pagename);
						// Parse and replace shortcodes
						$parsed_content = parse_shortcodes($filename);
						echo $parsed_content;
					?>
			</div>
		</div>
	</main>

<!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->