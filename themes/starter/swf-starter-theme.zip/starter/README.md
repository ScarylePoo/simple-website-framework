# SWF Starter

A starting point for Simple Website Framework, in the spirit of the old WordPress
starter themes. Sane defaults, a handful of layout classes, and nothing you have to
remove before you can begin.

No web fonts. No `@import`. No build step. No JavaScript beyond StellarNav, which the
framework already loads.

Open `preview.html` and `preview-styleguide.html` to see it without installing
anything — both are static renders with the CSS inlined.

---

## Requires the revised base.css

This bundle includes `css/base.css` and `css/normalize.css`. **The theme assumes both.**

The earlier version of this theme was 1,017 lines, and roughly 400 of those were
overrides fighting the old `base.css` — the `137.5%` root size, the `vmin` headings,
the decorated blockquote, the glow on inline code. Those problems are fixed at the
framework level now, so the theme dropped to **628 lines** and no longer contains a
single "undo" rule.

If you install the theme against the *old* `base.css`, headings will resize when the
window gets short and code blocks will render at half size. Copy the `css/` folder too.

---

## Install

```
css/base.css               → css/base.css        (overwrites)
css/normalize.css          → css/normalize.css   (overwrites)
themes/starter/            → themes/starter/
pages/home.html            → pages/home.html
pages/styleguide.html      → pages/styleguide.html
pages/navigation.html      → pages/navigation.html
pages/footer/footer1-3.html → pages/footer/
```

Then in `config/config.php`:

```php
$theme = "starter";
```

Rename the folder to whatever you like and point `$theme` at that instead.

---

## Where the work is divided

`base.css` owns readability. The theme owns everything visual and structural.

| Handled by `base.css` | Handled by the theme |
|---|---|
| Reset, box-sizing, media defaults | Palette and font choices |
| Heading scale, line heights, rhythm | Layout classes (`band`, `wrap`, `stack`, `cluster`) |
| Links, lists, quotes, tables, code | Buttons, cards, callouts |
| Focus rings, reduced motion | Nav, header, footer, page containers |
| `.lead` `.hug` `.flush` `.measure` `.table-scroll` `.visually-hidden` | `.eyebrow` `.muted` `.textalign-*` |

The theme never restyles a base element just to change a colour — it reassigns the
variable and lets `base.css` do it.

---

## Section 1 is the control panel

For most projects it's the only part of `custom.css` you need to touch.

```css
--font-heading: var(--font-sans);   /* try var(--font-serif) */

--color-text:  #1c1c1a;
--color-link:  #1c5ea8;
--color-bg:    #ffffff;

--width-page:  74rem;
```

Spacing steps are derived from `base.css`'s `--space`:

```css
--step-md: calc(var(--space) * 1.5);
```

So changing `--space` alone rescales the entire theme proportionally, rather than
requiring you to edit thirty margin values.

---

## Layout classes

Columns come from the framework's `css/flexgridsystem.css` — `row`, `column`,
`flex-basis-*`. The theme deliberately doesn't duplicate that. It adds what sits
around it:

| Class | Does | Modifiers |
|---|---|---|
| `band` | Full-width horizontal band with vertical padding | `band-tight` `band-loose` `band-sunk` `band-inverse` |
| `wrap` | Centred max-width container with gutters | `wrap-narrow` `wrap-wide` |
| `stack` | Even vertical gap between direct children | `stack-lg` `stack-xl` |
| `cluster` | Horizontal group that wraps | `cluster-center` `cluster-between` |
| `card` | Bordered box with padding | — |
| `note` | Callout with an accent rule | — |
| `btn` | Button | `btn-outline` `btn-small` |

Reading width comes from `.measure` in `base.css`; the theme adds `.measure-center`.

The standard page section:

```html
<section class="band band-sunk">
    <div class="wrap">
        <h2>Heading</h2>
    </div>
</section>
```

**The band is not called `section` on purpose.** `page-html.php` and friends already
emit `<div class="section group">`, so a `.section` rule would quietly pad the inside
of every page.

---

## Template changes from skeleton

| File | Change |
|---|---|
| `header.php` | Closes `</head>` and opens `<body>` before the nav, so the header and nav are actually inside the body. Adds a skip link. Hero is a plain text block — no background image, no fixed height, no Font Awesome down-arrow. |
| `page-*.php`, `postarchives*.php` | Dropped the now-duplicate `</head><body>`; `.contentcontainer` is a `<main>`. Otherwise unchanged. |
| `footer.php` | Wrapped in `<footer>`, added a copyright row. |
| `page-blank.php` | **New.** Full-bleed layout, no container, no page title — for landing pages that manage their own sections. Set `pagelayout:page-blank` in the page metadata. |
| `navigation.css`, `navigation.php`, `navigation-options.php` | Unchanged. The nav is recoloured by overriding its variables in `custom.css`. |

---

## Included pages

- **`home.html`** — uses `page-blank`, demonstrates each layout class. Made to be deleted.
- **`styleguide.html`** — every element the baseline and theme style, on one page. Keep
  it while you customise; if you break something it shows up here first.

---

## Accessibility

`base.css` provides the focus ring, `prefers-reduced-motion`, unitless line heights
and the capped measure. The theme adds a skip link and keeps contrast above 4.5:1 in
both colour schemes.

`prefers-color-scheme: dark` is one self-contained block of variable reassignments in
section 1. Delete it if you don't want dark mode — no rule below it depends on it.
